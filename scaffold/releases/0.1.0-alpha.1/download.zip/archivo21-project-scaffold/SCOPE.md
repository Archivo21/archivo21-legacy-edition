# Scope

Scope describes the work this project is prepared to do now. It is not a verdict on what the project may become later.

## 1. Current scope statement

> `[During this phase, the project will ...]`

## 2. Included

The current phase includes:

- `[Subject, collection or problem]`
- `[Time period or geographic area]`
- `[Kinds of source or evidence]`
- `[Kinds of work]`
- `[Kinds of output]`

## 3. Excluded for now

The current phase does not include:

- `[Adjacent subject]`
- `[Unverified expansion]`
- `[Output requiring resources not yet available]`
- `[Work belonging to another project or institution]`

“Excluded for now” does not mean “unimportant.”

## 4. Boundaries

### Subject boundary

`[What belongs to the project’s subject, and what merely resembles it?]`

### Time boundary

`[Dates, eras, release versions or project phases included.]`

### Geographic boundary

`[Locations included, if relevant.]`

### Evidence boundary

`[Which sources can support conclusions? Which can inspire questions but not prove them?]`

### Public/private boundary

`[What may be published, what must remain restricted, and why?]`

### Responsibility boundary

`[What the project can responsibly claim, host, preserve or maintain.]`

## 5. Scope-change triggers

Review this document when:

- new material changes the project’s understanding of its subject;
- a new output requires materially different rights, skills or resources;
- another project or institution becomes involved;
- the first success criteria are completed;
- the current boundary prevents necessary work;
- expansion begins to obscure the original purpose.

## 6. Scope-change test

Before expanding, answer:

1. What concrete problem requires the expansion?
2. Does it belong here or deserve its own project?
3. What new rights, risks, costs or responsibilities appear?
4. Which current work would be delayed?
5. Can the expansion be tested in a smaller form?
6. Does the subject remain recognisable?

Record approved changes in `DECISION-LOG.md`.
