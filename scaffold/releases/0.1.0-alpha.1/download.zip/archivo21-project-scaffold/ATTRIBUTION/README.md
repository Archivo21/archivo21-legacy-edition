# Archivo 21 Attribution Pack

This folder makes correct attribution easy.

## What is licensed

The reusable documentary materials in this Scaffold are licensed under CC BY 4.0, subject to the exclusions in `../LICENSE.md`.

## What attribution does not mean

Using or crediting the Scaffold does not mean that Archivo 21:

- supports the project;
- approves it;
- reviewed its work;
- hosts or funds it;
- is responsible for its outputs;
- has accepted it into an adoption registry.

## Ready-made options

Use `ATTRIBUTION-TEXT.md` for:

- root README acknowledgement;
- website notice;
- compact notice;
- modified-framework notice;
- no-link fallback.

## Full-name rule

Write **Archivo 21** in full at first mention. Afterwards, `A21` may be used.

For Latin-script languages, keep the institutional name as **Archivo 21**.

For non-Latin writing systems, use either:

- `Archivo 21` in Latin characters; or
- an officially approved script-specific form.

Do not invent and present a transliteration as an official name.

## Logo

This private alpha points to the current official logo source in `CURRENT-LOGO.md` and `CURRENT-LOGO.url`.

Before a public Scaffold release, the current approved logo binary should be bundled and checksummed.

The logo is not licensed under CC BY 4.0. See `BRAND-AND-NON-ENDORSEMENT.md`.
