# Ready-Made Attribution Text

Replace bracketed fields where necessary.

## 1. Recommended root README acknowledgement

> This project uses the **Archivo 21 Project Scaffold `0.1.0-alpha.1`**, created by Archivo 21. The Scaffold materials are available under the Creative Commons Attribution 4.0 International licence. Use of the Scaffold does not imply Archivo 21 support, review, approval or affiliation.  
> Canonical site: https://archivo21.org/

## 2. Recommended website notice

> Project structure developed using the **Archivo 21 Project Scaffold `0.1.0-alpha.1`**. Archivo 21 originated the Scaffold framework but is not responsible for, affiliated with or presumed to endorse this project. Scaffold licence: CC BY 4.0.

## 3. Compact notice

> Uses Archivo 21 Project Scaffold `0.1.0-alpha.1` · CC BY 4.0 · No endorsement implied.

## 4. Modified-framework notice

> This project uses an adapted working copy of the **Archivo 21 Project Scaffold `0.1.0-alpha.1`**. Changes were made by `[project/person]`. Archivo 21 originated the Scaffold and does not necessarily support, review or endorse this adaptation or project.

## 5. Redistributed original copy

> This directory contains an unchanged copy of **Archivo 21 Project Scaffold `0.1.0-alpha.1`**. Verify it against the included SHA-256 manifest. The surrounding project may contain separate material under different terms.

## 6. Exact version not embedded

> This project used **Archivo 21 Project Scaffold `[version]`**. The exact original package is preserved by or linked through `[location]`. Archivo 21 originated the Scaffold. No endorsement or affiliation is implied.

## 7. No-link fallback

Use only where the medium cannot carry a link or full package:

> Built using the Archivo 21 Project Scaffold. No affiliation or endorsement implied.

## 8. Spoken/audio credit

> Project structure developed using the Archivo 21 Project Scaffold, version `[version]`. Archivo 21 is credited as the framework originator and is not implied to endorse this project.

## Legal minimum and fuller provenance

CC BY 4.0 requires appropriate credit, a licence link and an indication of changes when licensed material is shared.

Archivo 21 additionally recommends preserving:

- the exact Scaffold version;
- an unchanged original copy where practical;
- the package checksum;
- a canonical Archivo 21 link;
- an explicit non-endorsement statement.

The fuller record helps preservation and provenance, but does not replace the standard licence.
