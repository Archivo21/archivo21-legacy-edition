# Current Archivo 21 Logo Source

**Status:** Reference for private alpha `0.1.0-alpha.1`  
**Checked against repository:** 2026-07-29

## Canonical asset

https://archivo21.org/assets/images/archivo21-provisional-logo-transparent.png

## Repository record

**Path:** `Archivo21/archivo21.github.io: assets/images/archivo21-provisional-logo-transparent.png`  
**Git blob SHA:** `ec05fc505fcf5189374647e3dac85f6ec32d10e8`

## Use

This source pointer identifies the current provisional Archivo 21 logo used by the institutional website at the time this alpha was assembled.

The binary asset is not embedded in this private alpha package.

Before any public Scaffold release:

1. obtain the current approved logo directly from Archivo 21’s canonical site or repository;
2. place the approved binary files in this attribution pack;
3. record file formats and dimensions;
4. add their SHA-256 checksums to the package manifest;
5. confirm that the Brand and Non-Endorsement Policy still applies.

Do not replace the historical logo inside an already published Scaffold package. Publish an updated attribution pack separately or create a new Scaffold release.
