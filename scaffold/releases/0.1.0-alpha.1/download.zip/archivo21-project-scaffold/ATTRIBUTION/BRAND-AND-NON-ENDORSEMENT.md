# Brand and Non-Endorsement Policy

**Status:** Alpha policy for Scaffold testing

## Separate systems

The Scaffold’s reusable documentary materials are openly licensed.

The Archivo 21 name, logos, wordmarks, seals and badges are institutional identity marks and are not included in that content licence.

## Permitted without separate permission

You may:

- name Archivo 21 accurately as the originator of the Project Scaffold;
- quote the ready-made attribution text;
- link to the canonical Archivo 21 site or repository;
- display an unmodified approved attribution logo solely to identify the Scaffold’s origin, when supplied in an official attribution pack;
- describe the exact Scaffold version used.

## Not permitted by ordinary Scaffold use

You may not:

- use the Archivo 21 logo as your project’s own logo;
- put “Archivo 21” into your project or product name in a way implying ownership or affiliation;
- claim Archivo 21 support, review, approval, hosting or funding;
- create unofficial “approved,” “supported” or “certified” Archivo 21 badges;
- materially alter the logo and present it as official;
- use institutional marks on unrelated merchandise or promotions;
- imply that compliance with the Scaffold is a quality certification.

## False affiliation

Where Archivo 21 preserves a record of a false affiliation claim, the correction should appear prominently in the filename, title, list-item name or immediately visible description.

## Accurate factual statements

Acceptable:

> “This project uses the Archivo 21 Project Scaffold.”

Not acceptable without separate factual basis and permission:

> “An Archivo 21 project.”  
> “Approved by Archivo 21.”  
> “Official Archivo 21 partner.”

## Current-logo rule

A Scaffold release uses the current approved logo at the time of that release.

Historical packages remain frozen. A project may use the historical bundled attribution pack or a newer official attribution pack from the Archivo 21 website.

## Removal and correction

Archivo 21 may ask for correction of misleading identity-mark use without revoking anyone’s access to the openly licensed Scaffold materials.
