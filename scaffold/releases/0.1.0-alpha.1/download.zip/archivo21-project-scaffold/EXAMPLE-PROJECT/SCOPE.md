# Scope

## 1. Current scope statement

> During the v0.1 pilot, KTTR will inspect, photograph, digitise and document three selected cassettes from the eight-cassette collection and create private preservation and access copies.

## 2. Included

- physical inspection of three cassettes;
- photographs of cassettes, cases and labels;
- flat, minimally processed WAV capture;
- MP3 access copies;
- basic metadata;
- speaker-identification questions;
- rights and privacy classification;
- selective transcript notes;
- archive and continuity testing.

## 3. Excluded for now

- public online release;
- the remaining five cassettes;
- aggressive audio restoration;
- new oral-history interviews;
- commercial distribution;
- claims about local historical significance;
- disposal of original cassettes.

## 4. Boundaries

### Subject boundary

The project documents the recordings and their immediate provenance. It does not become a general genealogy or town-history project.

### Time boundary

The labels suggest 1987–1996. Dates remain provisional unless supported by internal references or reliable family evidence.

### Geographic boundary

The apparent recording area is one unnamed English town. The location remains private during the pilot.

### Evidence boundary

Tape labels and direct audio content support basic description. Family recollection may support hypotheses but does not automatically establish dates or identities.

### Public/private boundary

All audio remains private during the pilot. Metadata may later be made public only after rights and privacy review.

### Responsibility boundary

KTTR can preserve copies it lawfully holds. It cannot grant rights owned by speakers, performers or other creators.

## 5. Scope-change triggers

Review after three tapes are complete, or earlier if a tape contains highly sensitive personal material.

## 6. Scope-change test

Expansion requires proof that the workflow is safe, repeatable and preservable, not merely that five tapes remain.
