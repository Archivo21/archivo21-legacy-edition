# Example Project: The Kitchen Table Tape Rescue

**Status:** Fictional worked example  
**Purpose:** Demonstrate the Scaffold in use  
**Not an Archivo 21-supported project**

The Kitchen Table Tape Rescue is a fictional one-person pilot preserving a small box of family and neighbourhood cassette recordings from 1987–1996.

The example deliberately produces more than prose:

- preservation-quality audio;
- access copies;
- cassette and box photographs;
- a source and rights register;
- selective transcripts;
- a small offline listening set;
- a continuity package.

No real people, recordings or rights are represented.

## First-cycle result

Digitise and document three cassettes, produce checksummed WAV preservation files and MP3 access files, secure participant/rights decisions, and test whether a second person can locate and play the material from the archive manifest.

## Why this example exists

It demonstrates:

- mixed media;
- uncertain provenance;
- identifiable people;
- public/private separation;
- small-scale rights review;
- physical-object custody;
- a finishable pilot;
- structure activated by real triggers rather than decorative governance.
