# Output Register

| ID | Output | Medium | Audience | Status | Class | Version | Location | Preservation state |
|---|---|---|---|---|---|---|---|---|
| OUT-001 | T001 preservation master | WAV | Custodian | Planned | Private | 0.1 | `private-audio/T001/` | Two-drive copy required |
| OUT-002 | T001 access copy | MP3 | Trusted reviewer | Planned | Restricted | 0.1 | `access/T001/` | Derived from verified master |
| OUT-003 | T001 object record | JPEG + Markdown | Custodian/reviewer | Draft | Restricted | 0.1 | `objects/T001/` | Included in manifest |
| OUT-004 | Three-tape pilot report | Markdown/PDF | Custodian | Planned | Private | 0.1 | `reports/` | Release after pilot |

## OUT-001 acceptance test

The WAV file:

- contains complete Side A and Side B captures;
- is 96 kHz/24-bit PCM;
- has no digital clipping;
- plays from beginning to end;
- maps to T001 photographs;
- has a recorded SHA-256 checksum;
- exists on two separate drives.
