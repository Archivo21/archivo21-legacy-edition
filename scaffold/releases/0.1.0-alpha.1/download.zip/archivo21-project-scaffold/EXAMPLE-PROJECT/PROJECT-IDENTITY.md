# Project Identity

## 1. Project name

**Full name:** The Kitchen Table Tape Rescue  
**Short identifier:** KTTR  
**Current phase:** v0.1 pilot

## 2. One-sentence definition

> The Kitchen Table Tape Rescue preserves a small collection of domestic cassette recordings by digitising the audio, documenting the physical objects and creating access copies whose rights and privacy status are explicit.

## 3. Subject and emotional centre

The subject is informal recorded memory: people testing tape recorders, speaking across a kitchen table, recording local events and preserving voices without intending to create an archive.

The project must retain the intimacy and ordinariness of the recordings. It should not describe every casual tape as historically monumental.

## 4. Why this project exists

The cassettes are ageing, labels are incomplete and playback equipment is becoming less common. Some voices may no longer be identifiable later.

Existing family knowledge is oral and could disappear. The project therefore preserves both the audio and the uncertain context around it.

## 5. First useful output

**Output:** Three-cassette pilot preservation set  
**Audience:** Collection custodian and one trusted family reviewer  
**Form:** WAV audio, MP3 access copies, photographs, metadata and selective transcript notes

## 6. Current stage

- [x] Pilot: first repeatable work

## 7. People, agents and responsibility

| Identifier or name | Role | Material contribution | Authority | Limitations |
|---|---|---|---|---|
| Maya R. | Accountable human and collection custodian | Selects tapes, digitises, records provenance and approves access | Final responsibility for custody, consent and release | Cannot identify every speaker alone |
| KTTR-AI-001 | AI transcription and documentation assistant | Drafts file descriptions and transcript candidates | Advisory only | Cannot verify speaker identity or consent |

## 8. Canonical locations

| Function | Location |
|---|---|
| Primary working copy | `D:/KTTR/working/` |
| Public release location | Not yet public |
| Private source material | Locked external drive, `KTTR/private-audio/` |
| Backup/archive | Second encrypted drive held off-site |
| Contact route | Collection custodian’s private email |

## 9. Relationship to any parent body

Independent fictional project. Use of the Archivo 21 Project Scaffold does not create affiliation.

## 10. Non-goals

The pilot is not currently trying to:

- publish every recording online;
- identify every speaker;
- restore damaged audio aggressively;
- create a comprehensive local-history archive;
- collect new interviews.

## 11. Identity safeguard

> This project must never become so professionally presented that it erases the domestic, incomplete and personal nature of the recordings.

## 12. Current state summary

**What exists now:** Eight cassettes, one working deck, a USB audio interface and partial handwritten labels.  
**What is uncertain:** Exact dates, some speaker identities and publication consent.  
**What happens next:** Inspect and photograph the first three cassettes before playback.
