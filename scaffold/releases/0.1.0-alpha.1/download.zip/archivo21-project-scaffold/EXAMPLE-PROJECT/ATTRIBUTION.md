# Attribution

This fictional worked example uses the **Archivo 21 Project Scaffold `0.1.0-alpha.1`**, created by Archivo 21.

Scaffold materials are licensed under CC BY 4.0. The example has been adapted to demonstrate a cassette-preservation pilot.

Use of the Scaffold does not imply Archivo 21 support, review, approval or affiliation.
