# Source Register

| ID | Source | Type | Creator/custodian | Date | Access | Rights | Preservation | Reliability/use | Location |
|---|---|---|---|---|---|---|---|---|---|
| SRC-001 | Cassette T001 “Christmas / kitchen” | Physical cassette + audio | Unknown recordist; Maya custodian | c. 1987–1992 | Private | Unclear | Original held | Direct audio and labels; date uncertain | Box A / slot 1 |
| SRC-002 | Cassette T003 “School play” | Physical cassette + audio | Unknown recordist; Maya custodian | 1991? | Private | Permission needed | Original held | Event title plausible; participants unidentified | Box A / slot 3 |
| SRC-003 | Cassette T006 unlabelled | Physical cassette + audio | Unknown | Unknown | Private | Unclear | Original held | No descriptive claim before listening | Box A / slot 6 |
| SRC-004 | Maya’s recollection of collection history | Oral recollection | Maya R. | 2026-07-29 | Restricted | Not applicable | Notes held | Supports acquisition history, not recording dates | `notes/provenance-maya.md` |

## SRC-001 detailed entry

**Original format:** Compact cassette  
**Access class:** Private  
**Rights status:** Unclear  
**Consent status:** Unknown  
**Working copy:** `working/T001/`  
**Checksum:** Added after capture

### Provenance

Maya found the cassette in a family storage box inherited from her aunt. The exact recordist is unknown.

### What it supports

- existence and physical wording of the labels;
- audio content after capture;
- approximate domestic context where audible.

### What it does not establish

- exact recording date;
- identity of every speaker;
- permission for public release.

### Preservation action

Photograph before playback, inspect shell and leader, capture both sides, retain original in inert case.
