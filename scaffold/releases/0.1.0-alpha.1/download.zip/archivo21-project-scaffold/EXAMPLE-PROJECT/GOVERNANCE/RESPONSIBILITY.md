# Responsibility

## Accountable human

**Name:** Maya R.

Maya controls physical custody, playback, access, consent decisions and any future publication.

## AI role

KTTR-AI-001 may draft metadata and suggest transcript wording.

Maya must verify:

- speaker labels;
- dates;
- rights claims;
- sensitive-content descriptions;
- technical capture notes.

AI-generated speaker identification is prohibited.

## Decision model

Accountable-human decision after documented consultation.

## Access

Only Maya may access raw masters during the pilot. One trusted reviewer may access derived MP3 files after a privacy check.
