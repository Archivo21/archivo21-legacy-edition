# Rights and Consent

| ID | Material/person | Intended use | Status | Evidence | Restrictions |
|---|---|---|---|---|---|
| R-001 | Voices on T001 | Private preservation | Proceed | Lawful physical custody; no public distribution | Raw and access audio private |
| R-002 | Possible music on T001 | Private preservation | Unclear | Not yet reviewed | No public release |
| R-003 | Named family participants | Trusted review | Pending | Direct contact required | Use pseudonym until confirmed |

## Pilot rule

Digitisation for private preservation does not automatically authorise publication.

## Sensitive material response

If a tape contains medical, sexual, financial, criminal, safeguarding or intensely private content:

1. stop descriptive transcription;
2. restrict the item;
3. record only the minimum necessary metadata;
4. consult the accountable human;
5. decide whether any access copy should exist;
6. preserve the decision privately.
