# Archive Manifest

**Project:** The Kitchen Table Tape Rescue  
**Manifest version:** 1  
**Accountable custodian:** Maya R.

## Scaffold provenance

**Scaffold version:** `0.1.0-alpha.1`  
**Original package:** Preserved unchanged in `archive/scaffold-original/`  
**Working adaptation:** Yes, project-specific files created under `EXAMPLE-PROJECT/`

## Archive locations

| Class | Location | Access | Backup |
|---|---|---|---|
| Working | `D:/KTTR/working/` | Maya | Nightly external copy |
| Private masters | Encrypted Drive A | Maya | Encrypted Drive B off-site |
| Physical cassettes | Box A, dry indoor cabinet | Maya | No duplicate physical object |
| Access copies | Encrypted reviewer folder | Maya + reviewer | Drive B |
| Documentation | `D:/KTTR/docs/` | Maya | Drive B |

## Planned manifest entries

| ID | Object | Format | Class | Verification |
|---|---|---|---|---|
| ARC-001 | T001 Side A master | WAV | Private | SHA-256 + playback |
| ARC-002 | T001 Side B master | WAV | Private | SHA-256 + playback |
| ARC-003 | T001 object photographs | JPEG | Restricted | SHA-256 + visual review |
| ARC-004 | T001 metadata | Markdown | Restricted | Git history + checksum |

## Known gaps

- exact recordist unknown;
- full speaker list unknown;
- exact dates uncertain;
- no calibration tape currently available.

These gaps are preserved as uncertainties, not repaired through invented metadata.
