# Decision Log

## D-001 — Adopt the Archivo 21 Project Scaffold

**Date:** 2026-07-29  
**Status:** Adopted

### Decision

KTTR uses Archivo 21 Project Scaffold `0.1.0-alpha.1` for its pilot. The original package is preserved separately. KTTR is independent and is not represented as an Archivo 21 project.

### Reason

The collection needs source, rights, output and continuity records without a large institutional structure.

### Accountable human

Maya R.

### Review trigger

After the three-cassette pilot.

---

## D-002 — Private-first access

**Date:** 2026-07-29  
**Status:** Adopted

### Decision

All audio remains private during the pilot. Only trusted reviewers receive access copies.

### Reason

Speaker identity, consent, copyright and sensitivity are not yet established.

### Affected records

- `GOVERNANCE/RIGHTS-AND-CONSENT.md`
- `OUTPUTS/OUTPUT-REGISTER.md`

### Review trigger

Completion of rights review for an individual recording.

---

## D-003 — Preserve flat capture

**Date:** 2026-07-29  
**Status:** Adopted

### Decision

The preservation master is a flat WAV capture. Noise reduction may be applied only to a separate derivative and must be documented.

### Reason

A minimally altered preservation copy retains future restoration options.

### Review trigger

If the capture chain changes or specialist advice identifies a defect.

---

## D-004 — No forced speaker identification

**Date:** 2026-07-29  
**Status:** Adopted

### Decision

Unknown speakers remain unknown. Family guesses are recorded as hypotheses, not metadata facts.

### Reason

A neat label is not worth false certainty.
