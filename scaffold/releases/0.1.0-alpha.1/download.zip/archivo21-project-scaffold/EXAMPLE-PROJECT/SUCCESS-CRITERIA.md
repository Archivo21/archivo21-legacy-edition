# Success Criteria

## 1. Current phase

**Phase:** Three-cassette pilot  
**Review trigger:** Completion or abandonment of the third cassette

## 2. Primary success test

> This phase succeeds when Maya and one trusted reviewer can use the archive manifest to locate, verify and play preservation and access copies for three cassettes while understanding each item’s rights, privacy and provenance status.

## 3. Required outputs

| ID | Output | Medium | Minimum acceptable state | Evidence |
|---|---|---|---|---|
| OUT-001 | Three preservation captures | 96 kHz/24-bit WAV | Complete sides, no clipping, documented chain | Playback test and checksum |
| OUT-002 | Three access sets | MP3 | Correctly named and playable | Reviewer test |
| OUT-003 | Object record | JPEG + Markdown | Case, cassette and labels photographed | Manifest |
| OUT-004 | Rights/provenance record | Markdown | Status explicit for every tape | Review |
| OUT-005 | Continuity package | Markdown + manifest | Newcomer can locate next action | Dry-run test |

## 4. Quality criteria

- capture begins before audible programme content and ends after it;
- no destructive cleaning is applied to originals;
- uncertain dates and identities remain labelled;
- raw preservation files remain private;
- filenames map unambiguously to physical items;
- another person can follow the archive without oral explanation.

## 5. Continuity criterion

The reviewer can identify the next undigitised tape and understand why public release has not been approved.

## 6. Media-form check

- [x] Audio is required.
- [x] Images are required.
- [x] Physical objects require documentation.
- [x] Text metadata is required.
- [x] A mixed output is required.

## 7. Failure conditions

- audio is captured but cannot be tied to a physical cassette;
- raw files are accidentally published;
- speaker identities are asserted without evidence;
- checksums or backups are missing;
- the process damages a cassette;
- documentation takes so long that digitisation never begins.

## 8. Stop condition

Pause immediately if playback threatens physical damage or reveals material requiring urgent privacy review.
