# Success Criteria

Success criteria turn intention into something inspectable.

## 1. Current phase

**Phase name:** `[Example: v0.1 pilot]`  
**Review date or trigger:** `[Date or event]`

## 2. Primary success test

Complete one sentence:

> This phase succeeds when `[a named person or audience]` can inspect or use `[specific output]` and verify `[specific quality or capability]`.

## 3. Required outputs

| ID | Output | Medium | Minimum acceptable state | Evidence of completion |
|---|---|---|---|---|
| O-001 | `[Output]` | `[Medium]` | `[Definition]` | `[File, test, review or observation]` |
| O-002 | `[Optional output]` | `[Medium]` | `[Definition]` | `[Evidence]` |

## 4. Quality criteria

The phase output should be:

- **Accurate:** claims are tied to evidence or labelled uncertainty.
- **Traceable:** sources and decisions can be followed.
- **Usable:** the intended audience can open, understand or operate it.
- **Preservable:** files, formats, rights and custody are documented.
- **Proportionate:** structure does not exceed the work’s current needs.
- **Recognisable:** the project’s subject and personality remain visible.

Add project-specific criteria:

- `[Criterion]`
- `[Criterion]`

## 5. Continuity criterion

Another person should be able to determine:

- the project’s current state;
- the next action;
- where the sources and outputs live;
- which uncertainties remain;
- who is accountable.

## 6. Media-form check

The project is not required to use multiple media.

However, confirm that output form follows the subject rather than the convenience of the template.

- [ ] Text is genuinely the appropriate output.
- [ ] Images are required.
- [ ] Audio is required.
- [ ] Video is required.
- [ ] Software or a playable file is required.
- [ ] Physical objects or media require documentation.
- [ ] A mixed output is required.

## 7. Failure conditions

This phase has failed or needs redesign if:

- documentation replaces the actual work;
- the project makes claims it cannot support;
- the output cannot be opened or understood by its intended audience;
- rights or consent are ignored;
- provenance is lost;
- the project’s identity is flattened;
- nobody can explain what happens next.

## 8. Stop condition

The phase should stop, pause or close when:

- all required criteria are met;
- a decisive blocker makes the phase impossible;
- risks exceed the project’s current capacity;
- another project is clearly the proper home;
- the subject or purpose no longer justifies continuation.

## 9. Review result

At review, mark one:

- [ ] Success: proceed to next phase
- [ ] Partial success: preserve outputs and revise
- [ ] Inconclusive: perform one smaller test
- [ ] Pause: continuity record completed
- [ ] Close: archive and closure note completed
