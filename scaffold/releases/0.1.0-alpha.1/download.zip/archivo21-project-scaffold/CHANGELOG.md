# Changelog

All notable changes to the Archivo 21 Project Scaffold will be recorded here.

Historical release packages remain frozen. Corrections and additions receive a new version.

## [0.1.0-alpha.1] — 2026-07-29

### Added

- first usable private alpha package;
- core project identity, scope and success templates;
- decision log and worklog;
- source registration and evidence-note system;
- output registration and release checks;
- archive manifest and continuity record;
- trigger-based governance module;
- rights, consent and publication review;
- ready-made Archivo 21 attribution text;
- brand and non-endorsement guidance;
- fully populated fictional example project;
- SHA-256 package manifest.

### Licensing

- documentary materials designated for CC BY 4.0;
- Archivo 21 identity marks expressly excluded from the content licence;
- commercial use, redistribution and private adaptations supported.

### Known limitations

- this alpha has not undergone an independent external pilot;
- the current Archivo 21 logo is referenced by canonical source rather than embedded as a binary asset;
- no formal multilingual naming register exists yet;
- the package has not received jurisdiction-specific legal review;
- some projects will require additional subject-specific structures.
