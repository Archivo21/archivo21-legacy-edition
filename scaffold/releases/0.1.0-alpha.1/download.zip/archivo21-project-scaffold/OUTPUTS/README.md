# Outputs

An output is something the project creates, preserves or makes usable.

Outputs may include:

- reports and guides;
- photographs and image collections;
- audio recordings and restored sound;
- video;
- software, mods and playable files;
- datasets;
- physical exhibits or object records;
- maps and models;
- websites;
- teaching material;
- mixed-media archives.

The Scaffold does not treat text as the default final form.

## Output rules

1. Define the intended audience.
2. Record the source and rights basis.
3. State the output’s current maturity.
4. Test whether another person can use or inspect it.
5. Preserve a release copy and checksum.
6. Keep public and private versions distinct.
7. Verify the published state after release.
8. Correct errors through a new version or visible advisory, not silent history editing.

## Files

- `OUTPUT-REGISTER.md` tracks all outputs.
- `RELEASE-CHECKLIST.md` is used before and after publication.
