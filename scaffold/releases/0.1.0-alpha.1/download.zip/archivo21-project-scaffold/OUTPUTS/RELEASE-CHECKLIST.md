# Release Checklist

Use this only when an output is actually being published or distributed.

## Before release

### Identity and scope

- [ ] Project and output names are correct.
- [ ] The release matches the approved scope.
- [ ] Status labels are honest.
- [ ] No claim implies authority the project does not possess.

### Evidence

- [ ] Major factual claims can be traced to sources.
- [ ] Inference and uncertainty are labelled.
- [ ] Known contradictions are not hidden.
- [ ] Tests were recorded.

### Rights, consent and privacy

- [ ] Rights status is recorded for included material.
- [ ] Required permission or consent exists.
- [ ] Personal data has been reviewed.
- [ ] Public and private materials are separated.
- [ ] Third-party notices are included.

### Usability

- [ ] Files open in the intended environment.
- [ ] Links and downloads work.
- [ ] Instructions have been tested by someone other than the author where possible.
- [ ] Accessibility basics have been checked.
- [ ] Required software, formats and dependencies are named.

### Preservation

- [ ] A frozen release copy exists.
- [ ] Version number is assigned.
- [ ] Changelog or release note exists.
- [ ] Manifest is complete.
- [ ] Checksums are generated.
- [ ] Backup location is recorded.
- [ ] Attribution notice is present.

## Publish

Record:

**Release date:** `[YYYY-MM-DD]`  
**Version:** `[Version]`  
**Publisher/accountable human:** `[Name]`  
**Public location:** `[URL]`  
**Release checksum:** `[Value]`

## After release

Do not assume upload equals publication.

- [ ] Open the public page or download from a separate session/device.
- [ ] Confirm the correct files are public.
- [ ] Confirm private/raw material is not exposed.
- [ ] Test navigation and direct links.
- [ ] Confirm version and attribution.
- [ ] Record differences between intended and actual public state.
- [ ] Correct through a documented new release or visible advisory.

## Release result

- [ ] Verified
- [ ] Verified with minor defects
- [ ] Withdrawn for correction
- [ ] Public state differs materially from approved release

**Notes:** `[Record what actually happened.]`
