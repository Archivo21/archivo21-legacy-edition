# Output Register

| ID | Output | Medium | Audience | Status | Rights/public class | Version | Location | Preservation state |
|---|---|---|---|---|---|---|---|---|
| OUT-001 | `[Name]` | `[Text/audio/etc.]` | `[Audience]` | `[Planned/draft/test/released]` | `[Public/restricted/private]` | `[Version]` | `[Path/URL]` | `[State]` |

## Detailed output entry

### OUT-XXX — `[Output name]`

**Purpose:** `[What this output enables.]`  
**Medium:** `[Format and form.]`  
**Audience:** `[Who it serves.]`  
**Owner/custodian:** `[Who controls the release copy.]`  
**Status:** `[Planned / working / review / released / superseded / withdrawn]`  
**Version:** `[Project output version.]`

#### Inputs and sources

- `[SRC-XXX]`

#### Rights and consent

`[What permits creation and release.]`

#### Acceptance test

> `[How someone can verify that the output works.]`

#### Public/private distinction

`[Describe any redactions, omitted raw files or restricted companion material.]`

#### Release location

`[URL, repository, archive path or not yet released.]`

#### Preservation copy

**Path:** `[Path]`  
**Checksum:** `[Algorithm:value]`  
**Manifest entry:** `[Reference]`

#### Known limitations

- `[Limitation]`

#### Next action

`[Action.]`
