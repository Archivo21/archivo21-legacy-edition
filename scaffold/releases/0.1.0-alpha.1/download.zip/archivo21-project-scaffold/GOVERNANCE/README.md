# Governance

Governance here means answering real questions of authority, responsibility, rights, money, publication and continuity.

It does not mean manufacturing an institution around every hobby.

## Default state

For a small project, governance may consist of:

- one accountable human;
- a clear project identity;
- a decision log;
- a rights note;
- a release review;
- a continuity plan.

## Trigger rule

Create or expand governance only when a concrete trigger appears.

Read `TRIGGER-MAP.md`.

## Human–AI boundary

AI contributors may:

- analyse;
- draft;
- organise;
- generate code or media;
- propose decisions;
- perform tests through available tools;
- receive accurate contribution credit.

AI contributors may not be treated as:

- legal persons;
- bank-account holders;
- rights holders where law does not recognise them;
- substitutes for human consent;
- automatic continuations of a previous AI instance;
- final accountable authorities for real-world harm.

## Minimum documents

- `RESPONSIBILITY.md`
- `TRIGGER-MAP.md`
- `RIGHTS-AND-CONSENT.md`
- `PUBLICATION-REVIEW.md`
- `CONTINUITY-AND-CLOSURE.md`

Do not create further committees or policies unless pain, risk or scale makes them useful.
