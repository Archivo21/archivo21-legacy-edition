# Continuity and Closure

Projects deserve a survivable pause and an honest ending.

## Interruption plan

**Maximum expected gap before review:** `[Period]`  
**Continuity record:** `ARCHIVE/CONTINUITY-NOTE.md`  
**Accountable custodian:** `[Name]`  
**Backup custodian:** `[Name or none]`

## Restart conditions

The project may restart when:

- canonical records are accessible;
- source and output integrity can be checked;
- accountable responsibility is assigned;
- rights and consent remain valid;
- the next action is understood.

## Dormancy decision

**Date:** `[Date]`  
**Reason:** `[Reason]`  
**Current state preserved:** `[Yes/no]`  
**Public notice required:** `[Yes/no]`  
**Review date:** `[Date/event]`

## Closure decision

Closure should record:

- why the project ended;
- what it achieved;
- what remains unfinished;
- where sources and outputs are held;
- what may remain public;
- what must remain restricted;
- who may lawfully resume or reuse the work;
- which identities, roles or affiliations end.

## Transfer

A transfer does not automatically transfer:

- personal consent;
- contributor identity;
- AI identity or memory;
- rights not held by the project;
- institutional affiliation;
- legal accountability.

Record new custody and authority explicitly.

## Final check

- [ ] Decision log closed or transferred
- [ ] Source register current
- [ ] Output register current
- [ ] Archive manifest current
- [ ] Rights restrictions attached
- [ ] Public state verified
- [ ] Contact or correction route preserved where appropriate
