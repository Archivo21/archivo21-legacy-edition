# Publication Review

## Proposed publication

**Output ID:** `[OUT-XXX]`  
**Version:** `[Version]`  
**Channel:** `[Website/repository/video/etc.]`  
**Proposed date:** `[Date]`  
**Accountable human:** `[Name]`

## Review

### Purpose

`[Why publish this now?]`

### Scope

- [ ] Within current project scope
- [ ] Scope change recorded if needed

### Evidence

- [ ] Claims trace to sources
- [ ] Uncertainties labelled
- [ ] Interpretations distinguishable from observations

### Rights and privacy

- [ ] Rights reviewed
- [ ] Consent reviewed
- [ ] Personal data reviewed
- [ ] Raw/private material excluded
- [ ] Third-party notices included

### Identity and attribution

- [ ] Project identity remains clear
- [ ] Contributors credited accurately
- [ ] Archivo 21 attribution included where Scaffold material is shared
- [ ] No false support or affiliation implication

### Technical and archival state

- [ ] Files tested
- [ ] Version assigned
- [ ] Manifest and checksum generated
- [ ] Frozen release copy preserved
- [ ] Public routes and downloads defined

## Decision

- [ ] Approved
- [ ] Approved with conditions
- [ ] Not approved
- [ ] Withdrawn

**Conditions/reason:** `[Text]`

## Post-publication verification

**Checked by:** `[Name]`  
**Date:** `[Date]`

- [ ] Public state matches approved release
- [ ] Direct downloads work
- [ ] Private material is absent
- [ ] Attribution and status are visible
- [ ] Errors or discrepancies recorded

**Result:** `[Verified / defect found / withdrawn]`

## Correction path

Do not silently rewrite historical packages.

Use:

- a new patch/minor/major version;
- a visible advisory;
- a documented withdrawal;
- a corrected public route;
- a preserved internal incident record.
