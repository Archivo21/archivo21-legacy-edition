# Rights and Consent

This file is a working rights map, not a substitute for legal advice.

## Rights register

| ID | Material/person | Rights holder or participant | Intended use | Status | Evidence | Restrictions |
|---|---|---|---|---|---|---|
| R-001 | `[Item/person]` | `[Name/unknown]` | `[Use]` | `[Cleared/pending/unclear]` | `[Consent/licence/source]` | `[Restrictions]` |

## Consent record

For interviews, photographs, personal testimony or identifiable participation, record:

- who consented;
- what they understood the project to be;
- what may be recorded;
- what may be published;
- whether name, pseudonym or anonymity applies;
- whether raw material may be retained privately;
- withdrawal or correction process;
- date and form of consent;
- any safeguarding concerns.

## Public/private separation

| Material | Public form | Private/raw form | Reason for restriction | Custodian |
|---|---|---|---|---|
| `[Material]` | `[Public version]` | `[Private version]` | `[Reason]` | `[Name]` |

## Unclear rights procedure

When rights are unclear:

1. do not imply permission;
2. preserve source and provenance privately where lawful;
3. limit publication to what is permitted;
4. seek the rights holder or competent advice where proportionate;
5. record attempts and uncertainty;
6. use description, quotation limits, linking or omission where appropriate.

## Withdrawal or correction request

Record:

**Requester:** `[Name/contact]`  
**Date:** `[Date]`  
**Material:** `[Item]`  
**Request:** `[Removal/correction/restriction/etc.]`  
**Authority/evidence:** `[Basis]`  
**Decision:** `[Outcome]`  
**Action taken:** `[Action]`  
**Public correction needed:** `[Yes/no and why]`

## Review triggers

- publication;
- new rights-holder information;
- participant request;
- platform takedown;
- change of intended use;
- commercial distribution;
- transfer to another custodian.
