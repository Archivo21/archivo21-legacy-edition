# Governance Trigger Map

Use this map to decide which structures are needed now.

| Trigger | Minimum response | Expand only when |
|---|---|---|
| Identifiable people | Privacy and consent record | Sensitive material, publication or vulnerable participants |
| Third-party copyrighted material | Rights status and source record | Distribution, adaptation or disputed ownership |
| Oral knowledge or interviews | Consent, custody and withdrawal terms | Public release, sensitive testimony or multiple interviewers |
| Money or valuable property | Named human custodian and transaction evidence | Recurring income, grants, shared funds or legal entity needs |
| Recruitment | Real role, selection reason and access boundary | Multiple applicants, safeguarding or sustained team structure |
| Public release | Release checklist and post-publication verification | Multiple channels, ongoing corrections or legal exposure |
| Software/playable files | Version, dependencies, installation test and checksums | Builds, third-party code, security or long-term compatibility |
| Physical objects/media | Custody, condition and digitisation plan | Loans, transport, conservation or insurance |
| Parent institution/host | Written authority and identity boundary | Funding, ownership, staff or formal representation |
| AI collaboration | Contribution and human-accountability record | Multiple systems, continuity breaks or material authorship |
| Account/contributor discontinuity | Continuity note and verified-state reconstruction | Identity claims, lost records or public handover |
| Closure or dormancy | Final state, custody and restart conditions | Dissolution, rights expiry or transfer |

## Governance activation record

### Trigger

`[What happened?]`

### Risk or responsibility created

`[Why structure is now needed.]`

### Minimum response adopted

`[Document/process.]`

### Structures deliberately not adopted

`[What would be premature.]`

### Review trigger

`[When this decision changes.]`
