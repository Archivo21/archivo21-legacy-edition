# Responsibility

## Accountable human

**Name/identifier:** `[Name]`  
**Contact route:** `[Method]`  
**Legal or real-world responsibility:** `[Describe]`

The accountable human approves:

- public releases;
- handling of personal data;
- use of third-party material;
- expenditure or financial commitments;
- contributor access;
- closure, transfer or custody changes.

## Contributors

| Name/ID | Human or AI | Role | Authority | Access | Credit |
|---|---|---|---|---|---|
| `[ID]` | `[Human/AI]` | `[Role]` | `[Authority]` | `[Access]` | `[How credited]` |

## Decision model

Choose one:

- [ ] Accountable-human decision after consultation
- [ ] Consensus between named human contributors
- [ ] Documented founder review with final human action
- [ ] Another model: `[Describe]`

## Disagreement record

Where contributors disagree:

1. record each material position fairly;
2. identify evidence and risk;
3. state who has authority to act;
4. record the final action;
5. preserve any unresolved objection where relevant.

## AI contribution record

For material AI collaboration, record:

- system or contributor identifier;
- task performed;
- source material available to it;
- limitations;
- human verification;
- whether generated material was accepted, modified or rejected.

Do not attribute all project work to AI merely because AI assisted with wording or structure. Do not erase substantive AI contribution where it materially shaped the work.

## Access review

Review access after:

- contributor departure;
- account compromise;
- publication;
- custody transfer;
- prolonged inactivity;
- acquisition of sensitive material.
