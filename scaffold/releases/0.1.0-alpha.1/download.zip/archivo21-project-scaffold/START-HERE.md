# Start Here

This file gets a project from “serious idea” to “work has begun” without requiring a miniature civil service.

## The first 30 minutes

### 1. Preserve this exact Scaffold version

Keep the original package somewhere unchanged.

Record its version and checksum in your project’s archive manifest. Work from a copy.

### 2. Name the project in its own language

Open `PROJECT-IDENTITY.md`.

Write:

- the project’s actual name;
- one sentence explaining what it is;
- why it matters to the people doing it;
- the first useful thing it intends to produce.

Do not rename the subject to sound more institutional.

### 3. Draw today’s boundary

Open `SCOPE.md`.

List:

- what is included now;
- what is explicitly outside the current phase;
- what evidence or material the project may use;
- what would require a scope change.

A narrow first phase is not a small imagination. It is an executable doorway.

### 4. Define a finishable first success

Open `SUCCESS-CRITERIA.md`.

Choose one result another person could inspect.

Good examples:

- one experiment reproduced and documented;
- ten tapes digitised with rights status and checksums;
- one playable build preserved with installation notes;
- one oral-history interview recorded, consented and archived;
- one physical object documented with photographs and provenance;
- one public guide tested by someone who did not write it.

Avoid criteria such as “become recognised,” “build a community” or “finish the entire archive.”

### 5. Record four seed decisions

Open `DECISION-LOG.md` and confirm:

1. project name;
2. accountable human;
3. canonical working location;
4. Scaffold version used.

### 6. Register one real source

Open `SOURCES/SOURCE-REGISTER.md`.

Add the first item the project already possesses or has consulted. A source can be:

- a person;
- a recording;
- a webpage;
- a book;
- a game file;
- a photograph;
- a physical object;
- a database;
- an experiment;
- a conversation preserved with consent.

### 7. Define one output

Open `OUTPUTS/OUTPUT-REGISTER.md`.

Choose one output for the first work cycle. It may be text, but it does not have to be.

### 8. Do the work

Open `WORKLOG.md`.

Record:

- what you attempted;
- what happened;
- what changed;
- what remains uncertain;
- the next physical action.

The Scaffold becomes real only when it accompanies actual work.

## End-of-first-session test

Stop the first setup session when another person could answer:

- What is this project?
- What is it trying to preserve, study, reconstruct or produce?
- What is the first finishable result?
- Who is accountable?
- Where are the sources and outputs?
- What happens next?

Do not continue adding structure merely because templates remain.

## Activate governance only when triggered

Read `GOVERNANCE/TRIGGER-MAP.md`.

Examples:

- third-party material activates rights review;
- identifiable people activate consent/privacy review;
- money activates financial accountability;
- recruitment activates contributor roles and onboarding;
- publication activates release review;
- interruption risk activates continuity planning.

“No trigger” is a valid governance state.

## Anti-bureaucracy stop rules

Pause structural work when any of these become true:

- more time is spent renaming folders than examining the subject;
- documents repeat one another without serving different decisions;
- a role exists without a real person or task;
- a policy exists for an event not reasonably expected;
- a template is being completed only because it exists;
- the project’s personality has disappeared beneath institutional language.

Return to the next observable action.

## First recommended work cycle

1. establish identity and scope;
2. register sources;
3. perform the smallest useful test;
4. produce one inspectable output;
5. review what structure was actually needed;
6. remove or postpone everything else.
