# Licence

## Licensed material

Except for the exclusions below, the original text, templates and documentary structure in this package are licensed by **Archivo 21** under the:

**Creative Commons Attribution 4.0 International Public License (CC BY 4.0)**  
Human-readable deed: https://creativecommons.org/licenses/by/4.0/  
Legal code: https://creativecommons.org/licenses/by/4.0/legalcode

Under CC BY 4.0, licensed material may be shared and adapted for any purpose, including commercially, provided the licence terms are followed.

## Required attribution when shared

When you share the original material or an adaptation, provide appropriate credit, link to the licence and indicate whether changes were made.

The ready-made text in `ATTRIBUTION/ATTRIBUTION-TEXT.md` is designed to make this easy.

CC BY 4.0 allows attribution in any reasonable manner. The full Archivo 21 attribution pack is a strongly recommended provenance practice, not a custom replacement for the standard licence.

## Private adaptations

You may keep an adapted working framework private.

Where no licensed material is shared, the public marking requirement is not triggered merely because an internal adaptation exists.

## Excluded material

The following are not licensed under CC BY 4.0 unless a separate notice expressly says otherwise:

- the name **Archivo 21** as an institutional identity mark;
- Archivo 21 logos, wordmarks, seals and badges;
- third-party material;
- personal data;
- material governed by separate rights or consent restrictions;
- content inside the fictional example that is explicitly identified as third-party or illustrative.

Accurate textual use of “Archivo 21” for attribution is permitted.

Logo and mark use is governed by `ATTRIBUTION/BRAND-AND-NON-ENDORSEMENT.md`.

## No endorsement

Attribution does not imply that Archivo 21:

- supports the adopting project;
- reviewed its work;
- approves its conclusions;
- hosts or funds it;
- is affiliated with it.

## No warranties

This alpha package is provided without warranties. Users remain responsible for checking whether its structure, licence and guidance are appropriate for their jurisdiction, subject and risks.

## Future code components

This release contains documentary materials, not a software library.

Any future executable code should carry a clearly identified OSI-approved software licence in addition to, or instead of, this documentation licence as appropriate.
