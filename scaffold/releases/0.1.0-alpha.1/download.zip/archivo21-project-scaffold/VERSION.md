# Version

**Current package:** `0.1.0-alpha.1`  
**Release date:** `2026-07-29`  
**Release state:** Private development alpha

## Numbering model

The Scaffold uses a semantic-style form:

```text
MAJOR.MINOR.PATCH
```

Optional prerelease labels may be added where useful.

### MAJOR

Changes to:

- mission;
- attribution rules;
- core philosophy;
- foundational governance or responsibility model.

A major version does not instruct adopters to update.

### MINOR

Backward-compatible additions such as:

- optional modules;
- templates;
- examples;
- guidance;
- supported output forms.

### PATCH

Non-substantive corrections such as:

- typo repairs;
- clearer wording without changed meaning;
- broken links;
- formatting;
- accessibility improvements;
- packaging repairs.

### Prerelease labels

- `alpha.n` for early distributed testing;
- `beta.n` for broader testing;
- `rc.n` for near-final testing where necessary.

## Frozen-release rule

Once a release is published, its contents should not be silently changed. Corrections become a new version.

## Adopter freedom

Projects choose which version they use. Archivo 21 does not invalidate older versions merely by publishing a newer one.

## Relationship to Semantic Versioning

This is a documentation-oriented adaptation of the `MAJOR.MINOR.PATCH` pattern. It is not a claim that the Scaffold is a software API.

Reference: https://semver.org/
