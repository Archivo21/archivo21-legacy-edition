# Worklog

The worklog records activity, not institutional theatre.

Use it to preserve:

- what was attempted;
- what happened;
- evidence created;
- decisions needed;
- blockers;
- next actions.

Keep decision outcomes in `DECISION-LOG.md`. Link to them from here.

## Entry format

### W-YYYY-MM-DD-01 — `[Session title]`

**Date:** `[YYYY-MM-DD]`  
**Participants:** `[Names/identifiers]`  
**Duration:** `[Optional]`  
**Related decisions:** `[D-XXX or “None”]`

#### Objective

`[What this session intended to accomplish.]`

#### Actions

1. `[Action]`
2. `[Action]`

#### Observations

- `[Directly observed fact.]`

#### Interpretations or hypotheses

- `[Label clearly.]`

#### Outputs created or changed

- `[Path or description.]`

#### Problems and uncertainties

- `[Problem or unknown.]`

#### Next physical action

> `[One action that can actually be performed.]`

---

## Initial entry

### W-YYYY-MM-DD-01 — Scaffold adoption

**Date:** `[YYYY-MM-DD]`  
**Participants:** `[Name/identifier]`

#### Objective

Create the project’s minimum working structure.

#### Actions

1. Preserved the original Scaffold package.
2. Created a working copy.
3. Began `PROJECT-IDENTITY.md`, `SCOPE.md` and `SUCCESS-CRITERIA.md`.
4. Registered the first source and first intended output.

#### Observations

- `[What became clearer once the project was written down?]`

#### Outputs created or changed

- `PROJECT-IDENTITY.md`
- `SCOPE.md`
- `SUCCESS-CRITERIA.md`
- `SOURCES/SOURCE-REGISTER.md`
- `OUTPUTS/OUTPUT-REGISTER.md`

#### Problems and uncertainties

- `[What remains uncertain?]`

#### Next physical action

> `[Perform the smallest useful test.]`
