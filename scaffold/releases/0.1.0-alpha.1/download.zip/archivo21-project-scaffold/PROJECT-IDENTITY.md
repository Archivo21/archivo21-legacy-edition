# Project Identity

Complete this document in the project’s own voice. Keep it concise enough that a new contributor can understand it in one sitting.

## 1. Project name

**Full name:** `[Enter the project’s own name]`  
**Short name or identifier:** `[Optional]`  
**Current version or phase:** `[Example: v0.1 pilot]`

## 2. One-sentence definition

> `[This project preserves / studies / reconstructs / creates ... by ...]`

## 3. Subject and emotional centre

Describe the actual subject.

What must remain recognisable even after the project becomes more organised?

`[Write 1–3 paragraphs.]`

## 4. Why this project exists

Explain:

- what could be lost, misunderstood, inaccessible or left unfinished;
- why the current contributors care;
- why existing documentation or archives are insufficient, where applicable.

`[Write the reason without inflating the project’s importance.]`

## 5. First useful output

Name the smallest output that would make the project real.

**Output:** `[Concrete result]`  
**Intended audience:** `[Who can use or inspect it]`  
**Form:** `[Text / image / audio / video / software / playable file / physical-media record / mixed]`

## 6. Current stage

Choose one:

- [ ] Seed: identity and first test
- [ ] Pilot: first repeatable work
- [ ] Active: sustained production
- [ ] Publication: preparing a public release
- [ ] Maintenance: preserving and correcting established work
- [ ] Dormant: paused but preserved
- [ ] Closing: orderly conclusion or transfer

## 7. People, agents and responsibility

| Identifier or name | Role | Material contribution | Authority | Limitations |
|---|---|---|---|---|
| `[Name/ID]` | Accountable human | `[Contribution]` | Final legal and real-world accountability | `[Limits]` |
| `[Name/ID]` | Human contributor | `[Contribution]` | `[Authority]` | `[Limits]` |
| `[AI name/ID]` | AI contributor or tool | `[Contribution]` | Advisory/drafting/technical role only unless otherwise defined | Cannot hold legal accountability |

Record only real participants. Do not create empty offices.

## 8. Canonical locations

| Function | Location |
|---|---|
| Primary working copy | `[Path or repository]` |
| Public release location | `[URL or “not yet public”]` |
| Private source material | `[Location and access rule]` |
| Backup/archive | `[Location]` |
| Contact route | `[Contact method or “not yet established”]` |

## 9. Relationship to any parent body

Choose one:

- [ ] Independent project
- [ ] Project hosted by another organisation
- [ ] Project supported by another organisation
- [ ] Internal project of a parent organisation
- [ ] Relationship not yet decided

Describe who owns, hosts, supports or can make decisions for the project.

`[A parent relationship must not be inferred merely from use of a framework.]`

## 10. Non-goals

This project is not currently trying to:

- `[Non-goal 1]`
- `[Non-goal 2]`
- `[Non-goal 3]`

## 11. Identity safeguard

Complete:

> This project must never become so professionally presented that it erases `[the subject, community, tone, purpose or method that gives it identity]`.

## 12. Current state summary

**What exists now:** `[Brief inventory]`  
**What is uncertain:** `[Known unknowns]`  
**What happens next:** `[One next action]`
