# Continuity Note

Write this so a responsible newcomer can understand the project without pretending to inherit anyone’s identity or memories.

## 1. What this project is

`[One concise description.]`

## 2. Current state

**Stage:** `[Stage]`  
**Last active date:** `[Date]`  
**Most recent completed result:** `[Result]`  
**Current blocker:** `[Blocker or none]`

## 3. Next action

> `[One physical action.]`

## 4. Canonical records

| Record | Location |
|---|---|
| Identity | `[Path]` |
| Scope | `[Path]` |
| Success criteria | `[Path]` |
| Decisions | `[Path]` |
| Sources | `[Path]` |
| Outputs | `[Path]` |
| Archive | `[Path]` |
| Rights/consent | `[Path]` |

## 5. People and responsibility

`[Who remains accountable, who should be contacted, and what authority each person has.]`

## 6. AI or account continuity

Where AI systems or online accounts were materially involved, record:

- platform/account used;
- what records survive outside the platform;
- what the replacement instance may verify;
- what identity or memory must not be assumed to transfer;
- which claims require reconciliation against files.

## 7. Known uncertainties

- `[Unknown]`

## 8. Restricted material

`[What exists privately and who may access it.]`

## 9. Safe restart procedure

1. Read identity, scope and latest decision.
2. Verify archive paths and public state.
3. Do not infer missing decisions.
4. Perform the smallest reversible test.
5. Record the restart in the worklog.
6. Review governance triggers before publishing, spending or recruiting.

## 10. Closure option

If the project should not resume, preserve:

- reason for closure;
- final state;
- custody;
- public notice where appropriate;
- rights restrictions;
- unresolved risks;
- instructions for lawful future access.
