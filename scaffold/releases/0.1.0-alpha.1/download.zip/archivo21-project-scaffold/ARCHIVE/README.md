# Archive

This folder preserves enough context for the project to survive interruption, migration, account loss, contributor change or closure.

## Archive principles

- Preserve the exact release, not only the latest working copy.
- Keep public, restricted and private classes visible.
- Record where originals live.
- Do not claim to possess missing material.
- Preserve known gaps as gaps.
- Generate checksums for exact digital objects.
- Document migrations and format changes.
- Keep continuity instructions readable without the original conversation.

## Minimum archive set

1. current project identity;
2. current scope and success criteria;
3. decision log;
4. source register;
5. output register;
6. archive manifest;
7. continuity note;
8. frozen released outputs;
9. rights and consent records where applicable.

## Historical versions

Final releases should be retained.

Alpha, beta or release-candidate versions should be retained when a real project used them and they are not already preserved accessibly by that project.

A historical package should not be silently changed.
