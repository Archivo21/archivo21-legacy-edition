# Archive Manifest

**Project:** `[Project name]`  
**Manifest version:** `1`  
**Last updated:** `[YYYY-MM-DD]`  
**Accountable custodian:** `[Name]`

## Scaffold provenance

**Scaffold:** Archivo 21 Project Scaffold  
**Version used:** `0.1.0-alpha.1`  
**Original package checksum:** `[SHA-256 from package manifest]`  
**Original package preserved at:** `[Path]`  
**Working copy modified:** `[Yes/no]`

## Archive locations

| Class | Location | Custodian | Access | Backup |
|---|---|---|---|---|
| Working | `[Path]` | `[Name]` | `[Access]` | `[Backup]` |
| Release | `[Path/URL]` | `[Name]` | Public/restricted | `[Backup]` |
| Private sources | `[Path]` | `[Name]` | Private | `[Backup]` |
| Offline/physical | `[Location]` | `[Name]` | `[Access]` | `[Plan]` |

## File manifest

| ID | Path or object | Version/date | Class | Format | SHA-256 or identifier | Notes |
|---|---|---|---|---|---|---|
| ARC-001 | `[Path]` | `[Version]` | `[Public/private/etc.]` | `[Format]` | `[Checksum]` | `[Notes]` |

## Missing or external material

| ID | Material | Why not held | Known location | Risk | Action |
|---|---|---|---|---|---|
| GAP-001 | `[Material]` | `[Reason]` | `[Location/unknown]` | `[Risk]` | `[Action]` |

## Migration history

| Date | Item | From | To | Method | Verification |
|---|---|---|---|---|---|
| `[Date]` | `[Item]` | `[Format/location]` | `[Format/location]` | `[Method]` | `[Checksum/test]` |

## Review trigger

Review this manifest after:

- a public release;
- repository migration;
- custody change;
- format migration;
- major source acquisition;
- interruption longer than the project’s normal work cycle;
- closure or transfer.
