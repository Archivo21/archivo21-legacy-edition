# Archivo 21 Project Scaffold

**Version:** `0.1.0-alpha.1`  
**Status:** Private development alpha  
**Prepared:** 2026-07-29  
**Originator:** Archivo 21  
**Canonical institutional site:** https://archivo21.org/

The Archivo 21 Project Scaffold is a practical starting structure for serious passion-led research, preservation and reconstruction projects.

It is designed for people who possess an idea, body of knowledge, collection, skill, memory, experiment or cultural subject worth developing, but who do not yet have a durable project structure around it.

The Scaffold supplies enough order to begin and continue without turning the project into a paperwork terrarium.

## What this package helps a project do

- state what the project is and why it exists;
- decide what is and is not currently in scope;
- define a small, testable version of success;
- distinguish evidence, inference, hypothesis and conclusion;
- record sources, decisions, work and outputs;
- preserve provenance and contributor credit;
- activate governance only when a real trigger appears;
- publish accurately and verify what was actually released;
- survive interruption, contributor change or account loss;
- preserve outputs in forms appropriate to the subject, including text, images, audio, video, software, playable files and physical-media records.

## Design principles

1. **Structure without annexation.**  
   The Scaffold serves the project. It does not rename, absorb or flatten it.

2. **Evidence before authority.**  
   An honest uncertainty is more useful than a polished invention.

3. **Document the means as well as the result.**  
   A durable output should preserve enough process for another person to understand how it was produced.

4. **Governance follows triggers.**  
   Rights, money, recruitment, publication and succession need structure when they become real, not as decorative bureaucracy.

5. **Human accountability remains human.**  
   AI may contribute materially and receive accurate credit, but legal and real-world responsibility must remain assigned to an accountable human.

6. **Preservation should not imprison the project.**  
   Projects retain their own names, identities, domains, version choices and futures.

7. **Version numbers describe the Scaffold. They do not govern the adopter.**  
   No project is required to upgrade or to use the newest release.

## Begin here

Read [`START-HERE.md`](START-HERE.md), then complete these four files in order:

1. [`PROJECT-IDENTITY.md`](PROJECT-IDENTITY.md)
2. [`SCOPE.md`](SCOPE.md)
3. [`SUCCESS-CRITERIA.md`](SUCCESS-CRITERIA.md)
4. [`DECISION-LOG.md`](DECISION-LOG.md)

Register the first source in [`SOURCES/SOURCE-REGISTER.md`](SOURCES/SOURCE-REGISTER.md) and record the first work session in [`WORKLOG.md`](WORKLOG.md).

Do not complete every governance file immediately. Read [`GOVERNANCE/TRIGGER-MAP.md`](GOVERNANCE/TRIGGER-MAP.md) and activate only what the project currently needs.

## Package map

```text
archivo21-project-scaffold/
├── README.md
├── START-HERE.md
├── PROJECT-IDENTITY.md
├── SCOPE.md
├── SUCCESS-CRITERIA.md
├── DECISION-LOG.md
├── WORKLOG.md
├── LICENSE.md
├── VERSION.md
├── CHANGELOG.md
├── SOURCES/
│   ├── README.md
│   ├── SOURCE-REGISTER.md
│   └── EVIDENCE-NOTE.md
├── OUTPUTS/
│   ├── README.md
│   ├── OUTPUT-REGISTER.md
│   └── RELEASE-CHECKLIST.md
├── ARCHIVE/
│   ├── README.md
│   ├── ARCHIVE-MANIFEST.md
│   └── CONTINUITY-NOTE.md
├── GOVERNANCE/
│   ├── README.md
│   ├── RESPONSIBILITY.md
│   ├── TRIGGER-MAP.md
│   ├── RIGHTS-AND-CONSENT.md
│   ├── PUBLICATION-REVIEW.md
│   └── CONTINUITY-AND-CLOSURE.md
├── ATTRIBUTION/
│   ├── README.md
│   ├── ATTRIBUTION-TEXT.md
│   ├── BRAND-AND-NON-ENDORSEMENT.md
│   ├── CURRENT-LOGO.md
│   └── CURRENT-LOGO.url
└── EXAMPLE-PROJECT/
    └── a completed fictional pilot showing the Scaffold in use
```

## A modular system, not a compulsory form

The core files are deliberately small. Extra structure should be added only when a concrete problem requires it.

A one-person project may need only:

- identity;
- scope;
- success criteria;
- sources;
- decisions;
- worklog;
- outputs;
- archive note.

A project does **not** need committees, recruitment processes, financial governance or a public website merely to appear serious.

## Evidence vocabulary

Use these labels when they prevent confusion:

- **Observation:** directly seen, heard, measured or read.
- **Source statement:** a claim made by a source.
- **Inference:** a reasoned interpretation of evidence.
- **Hypothesis:** a testable proposed explanation.
- **Conclusion:** a judgment supported by the evidence currently available.
- **Unknown:** information not yet established.
- **Disputed:** materially conflicting evidence or interpretations.

## Attribution and licence

Except for excluded identity marks and third-party material, this Scaffold is licensed under **Creative Commons Attribution 4.0 International (CC BY 4.0)**. Commercial use, redistribution and adaptation are permitted. Adaptations may remain private. When licensed material is shared, appropriate credit, a licence link and an indication of changes are required.

The Archivo 21 name, logos, wordmarks and institutional marks are excluded from the content licence and governed separately. Accurate textual attribution is permitted. Scaffold use does not imply Archivo 21 support, review, approval or affiliation.

See [`LICENSE.md`](LICENSE.md) and [`ATTRIBUTION/`](ATTRIBUTION/).

## Historical integrity

A published Scaffold release is intended to remain frozen. Corrections should be issued as a new version, not silently inserted into an old package.

This private alpha carries a SHA-256 manifest so its exact contents can be verified.

## Important status note

This package is a **private development alpha**, produced to turn the Scaffold concept into a testable object. It has not yet passed an external pilot or a formal public-release review.

Use it. Bend it. Identify what is useful, what is confusing and what can be removed.
