# Decision Log

Record decisions when they are made. Do not rely on memory to reconstruct them later.

## How to use this log

Each decision should state:

- the issue;
- the decision;
- the reason;
- the accountable person;
- evidence or constraints considered;
- affected records;
- unresolved questions;
- review trigger.

Do not rewrite old entries to make history look cleaner. Add a later decision that supersedes the earlier one.

## D-001 — Adopt this Scaffold version

**Date:** `[YYYY-MM-DD]`  
**Status:** Adopted unless replaced  
**Accountable human:** `[Name]`

### Issue

The project needs a starting structure for identity, scope, evidence, decisions, outputs and preservation.

### Decision

The project will begin with **Archivo 21 Project Scaffold `0.1.0-alpha.1`**.

The original package will be preserved unchanged. The project may modify its working copy and is not required to adopt later versions.

### Reason

`[Why this Scaffold was selected.]`

### Affected records

- `PROJECT-IDENTITY.md`
- `SCOPE.md`
- `SUCCESS-CRITERIA.md`
- `ARCHIVE/ARCHIVE-MANIFEST.md`

### Review trigger

Review only if the working structure obstructs the project or a different version offers a clearly useful feature.

---

## D-002 — Confirm project identity

**Date:** `[YYYY-MM-DD]`  
**Status:** `[Proposed / adopted / superseded]`

### Issue

`[What needed deciding?]`

### Decision

`[Exact outcome.]`

### Reason

`[Why this outcome was chosen.]`

### Accountable human

`[Name or identifier.]`

### Evidence and constraints

- `[Evidence or constraint]`

### Affected records

- `[File or system]`

### Unresolved questions

- `[Question or “None”]`

### Review trigger

`[Date, event or “No scheduled review.”]`

---

## Decision template

Copy this section for each new decision.

### D-XXX — `[Short title]`

**Date:** `[YYYY-MM-DD]`  
**Status:** `[Proposed / adopted / superseded / withdrawn]`

#### Issue

`[The decision that had to be made.]`

#### Decision

`[The precise outcome.]`

#### Reason

`[Why.]`

#### Accountable human

`[Name or identifier.]`

#### Contributors to the review

- `[Human or AI contributor and role]`

#### Evidence and constraints

- `[Evidence]`
- `[Constraint]`

#### Affected records

- `[File, output, process or repository]`

#### Unresolved questions

- `[Question]`

#### Review trigger

`[Date or event.]`
