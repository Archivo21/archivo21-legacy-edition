# Sources

This folder records what the project knows, where that knowledge came from and how confidently it may be used.

A source register is not a bibliography alone. It may include:

- documents;
- websites;
- recordings;
- interviews;
- software and data files;
- physical objects;
- photographs;
- experiments;
- direct observations;
- community knowledge;
- private archives.

## Core rules

1. Register a source before relying on it heavily.
2. Separate custody from permission to publish.
3. Preserve the original where lawful and practical.
4. Record uncertainty rather than invent missing provenance.
5. Do not treat a source’s statement as established fact automatically.
6. Distinguish public, restricted and private source material.
7. Use checksums for files whose exact identity matters.

## Evidence labels

- **Observation**
- **Source statement**
- **Inference**
- **Hypothesis**
- **Conclusion**
- **Unknown**
- **Disputed**

## Files

- `SOURCE-REGISTER.md` inventories sources.
- `EVIDENCE-NOTE.md` records detailed analysis of one source, claim or experiment.

Create additional evidence notes only where they help the work.
