# Source Register

## Status keys

**Access:** Public / Restricted / Private / Missing  
**Rights:** Cleared / Permission needed / Unclear / Not applicable  
**Preservation:** Original held / Copy held / External only / Lost

| ID | Source | Type | Creator/custodian | Date | Access | Rights | Preservation | Reliability/use | Location |
|---|---|---|---|---|---|---|---|---|---|
| SRC-001 | `[Title or description]` | `[Interview/file/object/etc.]` | `[Person or institution]` | `[Date/unknown]` | `[Status]` | `[Status]` | `[Status]` | `[What it can and cannot support]` | `[Path/URL/call number]` |

## Detailed source entry

### SRC-XXX — `[Short title]`

**Type:** `[Type]`  
**Creator:** `[Known creator or unknown]`  
**Current custodian:** `[Who holds it]`  
**Creation date:** `[Date, range or unknown]`  
**Acquisition date:** `[When the project obtained access]`  
**Access class:** `[Public / restricted / private / missing]`  
**Rights status:** `[Known status]`  
**Consent status:** `[Where people are identifiable]`  
**Original format:** `[Format or physical description]`  
**Working copy:** `[Path]`  
**Checksum:** `[Algorithm:value or not applicable]`

#### Provenance

`[How this item reached the project. Distinguish known facts from recollection.]`

#### What it supports

- `[Claim, question or reconstruction element]`

#### What it does not establish

- `[Limit]`

#### Preservation action

`[Copy, digitise, photograph, migrate, describe, link, or no action.]`

#### Review trigger

`[Event requiring another rights, reliability or preservation review.]`
