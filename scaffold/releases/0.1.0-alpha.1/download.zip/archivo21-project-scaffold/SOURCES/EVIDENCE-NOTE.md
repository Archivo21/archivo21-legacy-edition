# Evidence Note

**Evidence-note ID:** `EV-XXX`  
**Related source IDs:** `[SRC-XXX]`  
**Author/reviewer:** `[Name or identifier]`  
**Date:** `[YYYY-MM-DD]`

## Question

> `[What are we trying to establish?]`

## Direct observations

Record only what was directly observed, heard, measured or read.

1. `[Observation]`
2. `[Observation]`

## Source statements

Record what a source claims without silently adopting it as fact.

- `[Source] states that ...`

## Inferences

- `[Inference and reasoning.]`

## Hypotheses

- `[Testable proposed explanation.]`

## Conflicts or uncertainties

- `[Conflicting evidence, missing data or ambiguity.]`

## Smallest useful test

Describe the smallest action that could reduce uncertainty.

`[Test.]`

## Result

`[What happened.]`

## Current conclusion

Choose one:

- [ ] Supported
- [ ] Partly supported
- [ ] Not supported
- [ ] Inconclusive
- [ ] Disputed

`[Explain without overstating.]`

## Files created

- `[Path]`

## Next action

> `[One next evidence-producing action.]`
